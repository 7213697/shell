
var cookies = {CookieJD0:'pt_key=AAUw_Mpj0zybRZxJvv4GO4VSFc4LysTI7NkgS3OGgRVOM-gQ;pt_pin=jd_47e2d2c71c636;',}
var pins = process.env.pins
if(pins){
	pins = pins.split("&")
	for (var key in cookies) {
	    c = false
	    for (var pin of pins) {
		   if (pin && cookies[key].indexOf(pin) != -1) {
			  c = true
			  break
		   }
	    }
	    if (!c) {
		   delete cookies[key]
	    }
	}
}
module.exports = cookies